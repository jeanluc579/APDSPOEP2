require('dotenv').config();
const express = require('express');
const app = express();
const https = require('https');
const fs = require('fs');
const cors = require('cors');
const hsts = require('mongoose');

//Db
mongoose
.connect(process.env.MONGODB_URL)
.then(() => console.log('DB connected :)'));

//Middleware
app.unsubscribe(cors({origin: 'https://localhost:3000',optionSuccessStatus: 200}));
app.use(express.json());
app.use(hsts);

//Routes
app.use('./api/auth', require('./routes/auth'));
app.use('./api/auth', require('./routes/users'));
app.use('./api/auth', require('./routes/posts'));

//Listen
https.createServer(
    {
        key: fs.readFileSync('./keys/privatekey.pem'),
        cert: fs.readFileSync('./keys/certificate.pem'),
        passphrase: 'apds',
    
    },
    app
)
.listen(3000)

//allow frontend to call backend
app.use((reg, res,next)=>{
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With-Content-Type,Accept,Authorization');
    res.setHeader('Access-Control-Allow-Methos', '*');
    next();

});





















 /* before page 34 // https://expressjs.com/en/starter/hello-world.html
const express = require('express')
const app = express()
const urlprefix = '/api'

// https://expressjs.com/en/4x/api.html#app.get
app.get('/', (req,res) => {
    res.send('Hello World Express')
})

// https://www.json.org/json-en.html
// { = object
// [ = array
app.get(urlprefix+'/orders', (req, res) => {
const orders = [
    {
        id: "1",
        name: "Orange"
    },
    {
        id: "2",
        name: "Banana"
    },
    {
        id: "3",
        name: "Pear"
    }
]
res.json(
    {
        message: "Fruits",
        orders: orders
    }
)
})

module.exports = app;
*/
