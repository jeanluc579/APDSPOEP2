const router = require('express').Router();
const jwt = require('jsonwebtoken');
const {User} = require('../modles/User');
const {isValidpassword} = require('../utils/hash')

//login route
router.post('/', async (req, res) =>{
    const user = await User.findOne({username: req.body.username});
    if(!user)
    return res.status(400).json({error: 'Incorrect Username or Password'});

    const valid = await isValidpassword(req.body.password, user.password);

    if(!valid)
    return res.status(401).json({error: 'Incorrect username or Password'});

    const token = jwt.sign({userId: user._id}, process.env.JWT_SECRET_KEY);
    res.send({token});
});
module.exports = router;