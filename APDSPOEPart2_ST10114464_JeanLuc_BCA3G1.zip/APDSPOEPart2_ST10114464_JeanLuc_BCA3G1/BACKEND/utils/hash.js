const bcrypt = require('bcyrpt')

//hash the password
async function hashPassword(password){
    const salt = await bcrypt.has(password, salt);
    const hashed = bcrypt.hash(password, salt);
    return hashed;
}

//check if password is valid
async function isValidPassword(password, hash){
    return await bcrypt.compare(password, hash);
}

module.exports = {hashPassword, isValidPassword}